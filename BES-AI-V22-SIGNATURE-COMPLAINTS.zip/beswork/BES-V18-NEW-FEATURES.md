# BES V18 — Student Accounts + Admin Ads

## Student account flow
1. BES Admin creates/issues a Student ID and PIN from `admin.html`.
2. Student opens Student Login → Activate Account.
3. Student enters the BES ID + PIN provided by BES.
4. Student adds email, name, strong password, age (optional), class, roll number, subjects and optional photo.
5. After activation, normal login is **BES ID + PIN**.
6. Student can edit profile and photo from the Student Portal. The BES Student ID card updates from that profile.

## Privacy
- Public reviews never expose BES ID, email, roll number or profile details.
- Admin review moderation shows the linked student's private identity.
- Admin can hide/delete reviews and ban/unban/delete student accounts.

## Ads
- Admin Dashboard has **BES Ads & Announcements**.
- Add multiple slides (recommended 5–6), title, message, background hex color, image URL or gallery image, order and auto-slide interval.
- Published ads automatically appear in the public site's Latest Updates carousel.
- No active ads = carousel remains hidden.

## Database
Run `reviews-migration.sql` in Supabase SQL Editor once. It adds:
- student email/password/profile fields
- `ads` table
- review and ban support

## Cloudflare
After the migration, deploy the project again so the new Worker routes are live:
- `/api/student-signup`
- `/api/student-profile`
- `/api/ads`
- `/api/admin-ads`

Required Worker secrets remain:
- `OPENAI_API_KEY`
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `SESSION_SECRET`
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`
