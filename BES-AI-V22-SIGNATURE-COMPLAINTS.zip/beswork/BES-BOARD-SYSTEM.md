# BES Board System — Future Ready

The Worker test project now includes a database design for a future **BES Board**.

It is intentionally created as `draft` so it does not pretend that BES is already an official board.

## Planned structure

- BES Board settings
- Academic year
- Exam/session
- Class and field
- Subjects and marks
- Student roll number
- Published result
- Pass/fail/absent status

## Admin flow later

Admin Panel → BES Board → Academic Year → Exam → Class → Field → Subjects → Upload/Manage Results → Publish.

A student will only see a result after the admin publishes it.

The existing Karachi/other-board result system can remain separate from the future BES Board system.
