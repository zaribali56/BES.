-- BES Vercel + Supabase migration
-- Run this once in Supabase SQL Editor.
-- IMPORTANT: the service role key is only used by Vercel server-side functions.

DO $$
BEGIN
  IF to_regclass('public."Student"') IS NOT NULL AND to_regclass('public.students') IS NULL THEN
    ALTER TABLE public."Student" RENAME TO students;
  ELSIF to_regclass('public.student') IS NOT NULL AND to_regclass('public.students') IS NULL THEN
    ALTER TABLE public.student RENAME TO students;
  END IF;
END $$;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS public.students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id text UNIQUE,
  full_name text NOT NULL,
  class_level text NOT NULL CHECK (class_level IN ('9th','10th','11th','12th')),
  roll_number text NOT NULL,
  pin_hash text NOT NULL,
  pin_salt text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (class_level, roll_number)
);

ALTER TABLE public.students ADD COLUMN IF NOT EXISTS student_id text;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS full_name text;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS class_level text;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS roll_number text;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS pin_hash text;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS pin_salt text;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS active boolean NOT NULL DEFAULT true;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();

CREATE UNIQUE INDEX IF NOT EXISTS idx_students_student_id ON public.students(student_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_students_class_roll ON public.students(class_level, roll_number);

CREATE TABLE IF NOT EXISTS public.results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  title text NOT NULL,
  subject text,
  marks numeric,
  total_marks numeric,
  percentage numeric,
  grade text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_results_student ON public.results(student_id, created_at DESC);

-- These tables are accessed by Vercel server-side functions using the service-role key.
-- Keep RLS enabled so browser clients cannot directly read/write student data.
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.results ENABLE ROW LEVEL SECURITY;

-- BES Admin account: password is hashed and can be changed from the Admin Panel.
CREATE TABLE IF NOT EXISTS public.admin_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  password_salt text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.admin_accounts ENABLE ROW LEVEL SECURITY;

-- BES Reviews + account moderation
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS banned boolean NOT NULL DEFAULT false;
CREATE INDEX IF NOT EXISTS idx_students_banned ON public.students(banned);

CREATE TABLE IF NOT EXISTS public.reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating BETWEEN 1 AND 5),
  review_text text NOT NULL CHECK (char_length(review_text) BETWEEN 5 AND 800),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT reviews_one_per_student UNIQUE (student_id)
);
CREATE INDEX IF NOT EXISTS idx_reviews_public ON public.reviews(active, created_at DESC);
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

-- Student account activation/profile fields used by the Vercel API.
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS email text UNIQUE;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS password_hash text;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS password_salt text;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS age integer;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS subjects text;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS profile_photo text;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS profile_completed boolean NOT NULL DEFAULT false;

-- Admin-managed public announcement/ad carousel.
CREATE TABLE IF NOT EXISTS public.ads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  body text,
  image_url text,
  background_color text NOT NULL DEFAULT '#0b1824',
  active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  interval_ms integer NOT NULL DEFAULT 4500 CHECK (interval_ms BETWEEN 2000 AND 15000),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_ads_public ON public.ads(active, sort_order, created_at DESC);
ALTER TABLE public.ads ENABLE ROW LEVEL SECURITY;

ALTER TABLE students ADD COLUMN IF NOT EXISTS father_name TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS date_of_birth DATE;
ALTER TABLE students ADD COLUMN IF NOT EXISTS field TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS admission_year INTEGER;
ALTER TABLE students ADD COLUMN IF NOT EXISTS phone TEXT;
CREATE INDEX IF NOT EXISTS idx_students_year_class_field ON students(admission_year,class_level,field);


-- Multi-admin management. The original first account remains the BES Owner/Super Admin.
ALTER TABLE public.admin_accounts ADD COLUMN IF NOT EXISTS full_name text;
ALTER TABLE public.admin_accounts ADD COLUMN IF NOT EXISTS role text NOT NULL DEFAULT 'admin' CHECK (role IN ('super_admin','admin'));
ALTER TABLE public.admin_accounts ADD COLUMN IF NOT EXISTS permissions jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE public.admin_accounts ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES public.admin_accounts(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_admin_accounts_active ON public.admin_accounts(active);

UPDATE public.admin_accounts SET role='super_admin' WHERE id = (SELECT id FROM public.admin_accounts ORDER BY created_at ASC LIMIT 1);
