# Vercel Hobby Function Limit Fix

This version consolidates the BES API into one Vercel Serverless Function.

- Public URLs such as `/api/reviews`, `/api/ads`, `/api/health` continue to work.
- Student/admin API paths continue to use their original URLs.
- API implementations are stored under `server/api/`, not the top-level `api/` directory.
- `api/index.js` dispatches requests using the `route` rewrite query.

This is intended to keep the project below Vercel Hobby's 12-function deployment limit.


### Student self-registration
Run `supabase-self-registration.sql` once. The public Student Access page now has Create Account and Login as separate flows. New students register with email + name + a 6–8 character alphanumeric PIN + strong password; BES generates the Student ID and signs them into their portal. Profile details are completed afterward and the Student ID Card can be printed/saved as PDF.
