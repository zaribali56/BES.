# BES Reviews + Admin Protection

## What is included
- Separate public **Student Reviews** section on the home page.
- Anyone can read published reviews.
- Only a signed-in BES Student ID can create/update a review.
- One review per BES account; the student can update it later.
- Public review cards never expose BES ID, roll number, PIN, or private account details.
- Admin can see the private BES ID + student details behind every review.
- Admin can publish/hide/delete reviews.
- Admin can Ban/Unban student accounts.
- Banning an account automatically hides that student's review.
- Admin can also permanently delete student accounts.

## 1. Supabase
Run **`supabase-migration.sql`** once in Supabase SQL Editor. It now includes the reviews table and `students.banned` column.

## 2. Cloudflare Worker secrets
In Worker → Settings → Variables and Secrets, add:

- `OPENAI_API_KEY`
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `SESSION_SECRET`
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`

Use the same `SESSION_SECRET` everywhere the BES student/admin sessions are expected to work.

## 3. Deploy
Deploy the whole ZIP as the Cloudflare Worker project. The Worker handles `/api/*` and the static website is served from the project root.

After deployment:
1. Open the website.
2. Open **Reviews**.
3. As a public visitor, confirm reviews are visible but the write form says **BES ID Login Required**.
4. Login with a BES Student ID.
5. Return to Reviews and publish a 1–5 star review.
6. Open `/admin.html`, login as the configured admin, and check **Reviews & Moderation**.
7. Verify the admin sees the private BES ID/student details while the public review does not.
8. Test **Hide**, **Delete**, and **Ban ID**.
