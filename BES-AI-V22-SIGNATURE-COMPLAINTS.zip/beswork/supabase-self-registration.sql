-- BES V18 self-registration migration
-- Run this once in the Supabase SQL editor before using Create Account.
-- Existing admin-created students remain supported.

ALTER TABLE students ALTER COLUMN class_level DROP NOT NULL;
ALTER TABLE students ALTER COLUMN roll_number DROP NOT NULL;

-- Keep old data safe while allowing a newly registered student to complete
-- class/roll details after the account is created.
ALTER TABLE students DROP CONSTRAINT IF EXISTS students_class_level_check;
ALTER TABLE students ADD CONSTRAINT students_class_level_check
  CHECK (class_level IS NULL OR class_level IN ('9th','10th','11th','12th'));

CREATE UNIQUE INDEX IF NOT EXISTS idx_students_email_lower ON students (lower(email)) WHERE email IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_students_student_id ON students(student_id);
