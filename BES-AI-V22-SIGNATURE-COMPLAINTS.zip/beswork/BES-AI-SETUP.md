# BES-AI v3 — Student Private AI + Thinker

## What is included
- Separate `/bes-ai.html` page.
- Student login integration: signed-in students get a private BES-AI mode.
- Chat history is stored against the authenticated student UUID and is only fetched through the signed student session.
- Think Mode: teaches the student to reason instead of always giving the final answer.
- Photo input UI and Voice input UI.
- Optional public web research mode (Wikipedia summary endpoint) without an AI API key.
- Local BES-AI fallback knowledge so the page does not show “OPENAI_API_KEY missing”.
- Existing BES Student Portal remains intact.

## Database
Run the added `schema.sql` statements in the same Supabase database. The `ai_messages` table is required for private chat history.

## Vercel environment variables
Keep the existing:
- SUPABASE_URL
- SUPABASE_SERVICE_ROLE_KEY
- SESSION_SECRET

No OpenAI/Anthropic key is required for the included local BES-AI fallback.

## Important limitation
This version does not pretend that local rules are a full LLM. For full natural-language generation, photo understanding, video understanding, and stronger web research, a server-side model/search provider must be connected later. The UI and private student-chat architecture are already prepared for that upgrade.

## Academic data
The system is structured for Classes 9th–12th and all fields/groups, but actual official books, guess papers, model papers and past papers must be supplied by BES/admin rather than invented. Put verified material into the BES content database/storage and make it the primary source for answers.

## Admin Panel (V5)
1. Run `supabase-migration.sql` in Supabase SQL Editor.
2. Set `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `SESSION_SECRET`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD` in Vercel Environment Variables.
3. Open `/admin` after deployment and log in once using the Vercel admin credentials. The account is then securely initialized in `admin_accounts`.
4. After that, use **Change Password** inside `/admin`; the new password is stored as a server-side hash. Do not put the password in HTML/JS.


## Image generation
BES-AI can generate an image directly from a student's normal text or voice request; no separate image button is required. The browser voice input is converted to text, then the chat automatically detects an image request and calls `/api/ai-image`.

Vercel Production Environment Variables required:
- `OPENAI_API_KEY` — server-side OpenAI API key
- `OPENAI_IMAGE_MODEL=gpt-image-1`
- `OPENAI_IMAGE_QUALITY=medium`

Keep the API key server-side only; never put it in browser HTML/JavaScript.
