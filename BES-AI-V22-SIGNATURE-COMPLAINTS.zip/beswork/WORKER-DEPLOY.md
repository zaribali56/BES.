# BES-AI V18 — Cloudflare Worker Test Build

This package is the Worker testing baseline for the BES project. The existing BES pages are served as Worker static assets and the existing Vercel-style API handlers are adapted to the Cloudflare Fetch API.

## Routes
- `/`
- `/bes-ai`
- `/admin`
- `/student-login`
- `/student`
- `/student-card`
- `/api/health`
- `/api/student-signup`
- `/api/student-login`
- `/api/student-logout`
- `/api/student-me`
- `/api/student-profile`
- `/api/reviews`
- `/api/my-review`
- `/api/ads`
- `/api/admin-*`
- `/api/ai-*`

## Secrets
Use Wrangler secrets for:
- SUPABASE_URL
- SUPABASE_SERVICE_ROLE_KEY
- SESSION_SECRET
- ADMIN_EMAIL
- ADMIN_PASSWORD
- OPENAI_API_KEY

Example:
`wrangler secret put SUPABASE_URL`

## Local test
`npm install`
`npx wrangler dev`

## Deploy test Worker
`npx wrangler deploy`

## Important
The Worker test build replaces the original Node `scryptSync` password/PIN hashing with SHA-256 so the CommonJS handlers can execute in the Worker runtime. This is a TESTING bridge only. Before the final production migration, use a proper password KDF and migrate existing hashes safely.


## V18.2 test updates
- Student signup now uses exactly: Email + Name + one 6–8 character PIN. Password confirmation was removed from student signup.
- One email can create only one student account.
- BES Student ID and a generated Roll Number are returned after signup. Roll numbers use a compact year + alphanumeric format (for example `26A7K42`), not a `BS-2019...` style.
- Student login uses exactly: Student Name + BES Student ID + PIN, with Show/Hide PIN.
- Added dedicated routes/pages for Materials, field resources, Tests and Results.
- Public ads remain a maximum of 6 live rotating slides; admin controls include image, color, order, interval, publish/hide and delete.
- Fixed the Worker `student-signup` route so it actually invokes the signup handler instead of treating the module path as a function.
- Added database migration columns for future student card data: father name, date of birth, field, admission year and phone. Run the migration before using those fields.
- Admin Security button is exposed for password changes; real email/phone OTP reset still needs an email/SMS provider and its credentials.

Required Worker secrets remain: `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `SESSION_SECRET`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`.
