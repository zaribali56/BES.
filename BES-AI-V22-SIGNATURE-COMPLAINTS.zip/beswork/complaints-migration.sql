-- BES private Student Complaint & Support system
CREATE TABLE IF NOT EXISTS public.complaints (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
 subject text NOT NULL CHECK (char_length(subject) BETWEEN 3 AND 160),
 status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','in_review','resolved')),
 created_at timestamptz NOT NULL DEFAULT now(),
 updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_complaints_student ON public.complaints(student_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_complaints_status ON public.complaints(status, updated_at DESC);
CREATE TABLE IF NOT EXISTS public.complaint_messages (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 complaint_id uuid NOT NULL REFERENCES public.complaints(id) ON DELETE CASCADE,
 sender_type text NOT NULL CHECK (sender_type IN ('student','admin')),
 sender_id uuid,
 message text NOT NULL CHECK (char_length(message) BETWEEN 1 AND 3000),
 attachment_data text,
 attachment_name text,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_complaint_messages_thread ON public.complaint_messages(complaint_id, created_at);
ALTER TABLE public.complaints ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.complaint_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_accounts ADD COLUMN IF NOT EXISTS permissions jsonb NOT NULL DEFAULT '[]'::jsonb;
-- Add permission to existing admins where absent; Super Admin bypasses application permission checks.
UPDATE public.admin_accounts SET permissions = CASE WHEN jsonb_typeof(permissions)='array' AND NOT (permissions ? 'complaints.manage') THEN permissions || '["complaints.manage"]'::jsonb ELSE permissions END;
