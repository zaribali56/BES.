-- BES Board System (future-ready)
-- Adds a first-class private BES Board alongside Karachi/other boards.

create table if not exists public.bes_board_settings (
  id bigint generated always as identity primary key,
  board_code text not null unique default 'BES',
  board_name text not null default 'BES Board',
  board_type text not null default 'private',
  status text not null default 'draft' check (status in ('draft','active','inactive')),
  description text,
  logo_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.bes_board_exams (
  id bigint generated always as identity primary key,
  board_id bigint not null references public.bes_board_settings(id) on delete cascade,
  academic_year integer not null,
  exam_name text not null,
  class_name text not null,
  field_name text,
  exam_type text not null default 'annual',
  status text not null default 'draft' check (status in ('draft','published','closed')),
  start_date date,
  end_date date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.bes_board_subjects (
  id bigint generated always as identity primary key,
  exam_id bigint not null references public.bes_board_exams(id) on delete cascade,
  subject_code text,
  subject_name text not null,
  max_marks integer not null default 100,
  passing_marks integer,
  created_at timestamptz not null default now()
);

create table if not exists public.bes_board_results (
  id bigint generated always as identity primary key,
  exam_id bigint not null references public.bes_board_exams(id) on delete cascade,
  student_roll_number text not null,
  student_name text not null,
  subject_marks jsonb not null default '{}'::jsonb,
  total_marks integer,
  obtained_marks integer,
  percentage numeric(6,2),
  grade text,
  result_status text not null default 'pending' check (result_status in ('pending','pass','fail','absent')),
  published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (exam_id, student_roll_number)
);

create index if not exists idx_bes_board_exams_year on public.bes_board_exams(academic_year);
create index if not exists idx_bes_board_results_roll on public.bes_board_results(student_roll_number);

insert into public.bes_board_settings (board_code, board_name, board_type, status, description)
values ('BES', 'BES Board', 'private', 'draft', 'Future private examination board operated by BES.')
on conflict (board_code) do nothing;

-- Keep this board disabled until BES officially decides to run its own examinations.
