const {supabase,send,requireAdmin,adminSession,parseBody}=require('./_lib');
async function audit(sb,s,action,target,details={}){await sb.from('audit_logs').insert({actor_type:'admin',actor_id:s.adminId,action,target_type:'complaint',target_id:String(target),details});}
module.exports=async(req,res)=>{
 if(!requireAdmin(req))return send(res,401,{error:'Admin login required.'}); const s=adminSession(req);
 try{const sb=supabase();
  const {data:me,error:meErr}=await sb.from('admin_accounts').select('id,role,permissions,active').eq('id',s.adminId).maybeSingle();if(meErr)throw meErr;if(!me?.active)return send(res,403,{error:'Admin account is disabled.'});
  const perms=Array.isArray(me.permissions)?me.permissions:[]; if(me.role!=='super_admin'&&!perms.includes('complaints.manage'))return send(res,403,{error:'Complaint management permission required.'});
  if(req.method==='GET'){
   const {data,error}=await sb.from('complaints').select('id,student_id,subject,status,created_at,updated_at,students!inner(id,student_id,full_name,class_level,field,admission_year,date_of_birth,email,phone,father_name,father_phone,address,profile_photo),complaint_messages(id,sender_type,sender_id,message,attachment_data,attachment_name,created_at)').order('updated_at',{ascending:false}).limit(300);if(error)throw error;
   return send(res,200,{complaints:(data||[]).map(c=>({...c,complaint_messages:(c.complaint_messages||[]).sort((a,b)=>new Date(a.created_at)-new Date(b.created_at))}))});
  }
  const b=parseBody(req),id=String(b.id||'');if(!id)return send(res,400,{error:'Complaint ID is required.'});
  const {data:c,error:ce}=await sb.from('complaints').select('id,student_id,status').eq('id',id).maybeSingle();if(ce)throw ce;if(!c)return send(res,404,{error:'Complaint not found.'});
  if(req.method==='POST'){
   const message=String(b.message||'').trim();if(!message||message.length>3000)return send(res,400,{error:'Reply is required and must be 3000 characters or fewer.'});
   let attachmentData=null,attachmentName=null;if(b.attachmentData){attachmentData=String(b.attachmentData);attachmentName=String(b.attachmentName||'attachment');if(!/^data:image\/(png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=]+$/.test(attachmentData)||attachmentData.length>900000)return send(res,400,{error:'Please attach a valid image under 650 KB.'});}
   const {data:m,error:e}=await sb.from('complaint_messages').insert({complaint_id:id,sender_type:'admin',sender_id:s.adminId,message,attachment_data:attachmentData,attachment_name:attachmentName}).select('id,sender_type,message,attachment_data,attachment_name,created_at').single();if(e)throw e;
   await sb.from('complaints').update({status:'in_review',updated_at:new Date().toISOString()}).eq('id',id);await audit(sb,s,'complaint.replied',id,{});return send(res,201,{message:m});
  }
  if(req.method==='PATCH'){
   const status=['pending','in_review','resolved'].includes(b.status)?b.status:null;if(!status)return send(res,400,{error:'Invalid complaint status.'});await sb.from('complaints').update({status,updated_at:new Date().toISOString()}).eq('id',id);await audit(sb,s,'complaint.status_changed',id,{status});return send(res,200,{ok:true,status});
  }
  return send(res,405,{error:'Method not allowed.'});
 }catch(e){console.error(e);return send(res,500,{error:'Unable to manage complaints.'});}
};
