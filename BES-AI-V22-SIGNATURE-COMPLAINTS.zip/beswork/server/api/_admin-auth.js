const crypto=require('crypto');
const {supabase,hashPin,safeEqualHex}=require('./_lib');

async function getAccount(){
  const sb=supabase();
  const {data,error}=await sb.from('admin_accounts').select('id,email,full_name,role,permissions,password_hash,password_salt,active').limit(1).maybeSingle();
  if(error) throw error;
  return data;
}

async function verifyAdmin(email,password){
  const cleanEmail=String(email||'').trim().toLowerCase();
  const cleanPassword=String(password||'');
  if(!cleanEmail||!cleanPassword) return {ok:false,error:'Email and password are required.'};
  const sb=supabase();
  let account=await getAccount();
  if(!account){
    const envEmail=String(process.env.ADMIN_EMAIL||'').trim().toLowerCase();
    const envPassword=String(process.env.ADMIN_PASSWORD||'');
    if(!envEmail||!envPassword) return {ok:false,error:'Admin credentials are not configured.'};
    if(cleanEmail!==envEmail || cleanPassword!==envPassword) return {ok:false,error:'Invalid admin credentials.'};
    const salt=crypto.randomBytes(16).toString('hex');
    const passwordHash=hashPin(envPassword,salt);
    const {data,error}=await sb.from('admin_accounts').insert({email:envEmail,password_hash:passwordHash,password_salt:salt,active:true}).select('id,email,full_name,role,permissions,password_hash,password_salt,active').single();
    if(error && error.code!=='23505') throw error;
    account=data || await getAccount();
  }
  if(!account || !account.active || account.email.toLowerCase()!==cleanEmail) return {ok:false,error:'Invalid admin credentials.'};
  if(!safeEqualHex(hashPin(cleanPassword,account.password_salt),account.password_hash)) return {ok:false,error:'Invalid admin credentials.'};
  return {ok:true,account};
}

async function changePassword(currentPassword,newPassword){
  const account=await getAccount();
  if(!account) return {ok:false,status:404,error:'Admin account is not initialized. Log in once first.'};
  if(!safeEqualHex(hashPin(String(currentPassword||''),account.password_salt),account.password_hash)) return {ok:false,status:401,error:'Current password is incorrect.'};
  const next=String(newPassword||'');
  if(next.length<8) return {ok:false,status:400,error:'New password must be at least 8 characters.'};
  const salt=crypto.randomBytes(16).toString('hex');
  const hash=hashPin(next,salt);
  const sb=supabase();
  const {error}=await sb.from('admin_accounts').update({password_hash:hash,password_salt:salt,updated_at:new Date().toISOString()}).eq('id',account.id);
  if(error) throw error;
  return {ok:true};
}
module.exports={verifyAdmin,changePassword};
