const { supabase, send, hashPin, signSession, cookie, parseBody } = require('./_lib');
const crypto = require('crypto');

function makeId(){ return `BES-${String(new Date().getFullYear()).slice(-2)}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`; }
function calcAge(dob){
  if(!dob) return null;
  const d=new Date(dob+'T00:00:00Z');
  if(Number.isNaN(d.getTime())) return null;
  const now=new Date(); let age=now.getUTCFullYear()-d.getUTCFullYear();
  const m=now.getUTCMonth()-d.getUTCMonth();
  if(m<0 || (m===0 && now.getUTCDate()<d.getUTCDate())) age--;
  return age>=0 && age<130 ? age : null;
}
module.exports=async(req,res)=>{
  if(req.method!=='POST') return send(res,405,{error:'Method not allowed.'});
  try{
    const b=parseBody(req);
    const email=String(b.email||'').trim().toLowerCase();
    const name=String(b.name||b.fullName||'').trim();
    const fatherName=String(b.fatherName||'').trim();
    const dob=String(b.dateOfBirth||'').trim()||null;
    const phone=String(b.phone||'').trim();
    const fatherPhone=String(b.fatherPhone||'').trim();
    const address=String(b.address||'').trim();
    const classLevel=String(b.classLevel||'').trim();
    const field=String(b.field||'').trim();
    const pin=String(b.pin||'').trim();
    if(!email||!name||!fatherName||!dob||!phone||!fatherPhone||!address||!classLevel||!pin) return send(res,400,{error:'Please complete all required admission fields.'});
    if(!/^\S+@\S+\.\S+$/.test(email)) return send(res,400,{error:'Please enter a valid email address.'});
    if(name.length<2||fatherName.length<2) return send(res,400,{error:'Please enter valid names.'});
    if(!/^\d{4}-\d{2}-\d{2}$/.test(dob)) return send(res,400,{error:'Please enter a valid date of birth.'});
    if(!/^\+?[0-9 ()-]{7,20}$/.test(phone)) return send(res,400,{error:'Please enter a valid student mobile number.'});
    if(!/^\+?[0-9 ()-]{7,20}$/.test(fatherPhone)) return send(res,400,{error:'Please enter a valid father mobile number.'});
    if(!['9th','10th','11th','12th'].includes(classLevel)) return send(res,400,{error:'Invalid class selected.'});
    if(!/^[A-Za-z0-9]{6,8}$/.test(pin)) return send(res,400,{error:'PIN must be 6–8 letters/numbers.'});
    const sb=supabase();
    const {data:existing,error:emailError}=await sb.from('students').select('id,banned').ilike('email',email).limit(1).maybeSingle();
    if(emailError) throw emailError;
    if(existing) return send(res,409,{error:existing.banned?'This email is linked to a banned BES account.':'This email is already registered. Use Student Portal Login instead.'});
    let studentId=makeId();
    for(let i=0;i<5;i++){
      const {data:clash,error}=await sb.from('students').select('id').eq('student_id',studentId).limit(1).maybeSingle();
      if(clash) studentId=makeId(); else if(!error) break; else throw error;
    }
    const salt=crypto.randomBytes(16).toString('hex');
    const age=calcAge(dob);
    const now=new Date().toISOString();
    const admissionYear=new Date().getUTCFullYear();
    const {data:student,error}=await sb.from('students').insert({
      student_id:studentId, full_name:name, father_name:fatherName, date_of_birth:dob, age,
      phone, father_phone:fatherPhone, address, class_level:classLevel, field,
      admission_year:admissionYear, current_academic_year:admissionYear,
      roll_number:studentId, pin_hash:hashPin(pin,salt), pin_salt:salt,
      active:true,banned:false,email,profile_completed:true,admission_date:now
    }).select('id,student_id,full_name,father_name,date_of_birth,age,phone,father_phone,address,class_level,field,admission_year,current_academic_year,roll_number,email,profile_photo,profile_completed,active,banned,admission_date').single();
    if(error){ if(error.code==='23505') return send(res,409,{error:'This email or BES ID is already in use.'}); throw error; }
    const token=signSession({type:'student',studentId:student.id});
    return send(res,201,{student,message:'BES admission submitted successfully.',admissionDate:now},{'Set-Cookie':cookie('bes_student_session',token,60*60*12)});
  }catch(e){
    console.error('BES admission error:',e);
    if(String(e?.message||'').includes('Supabase environment variables are not configured')) return send(res,500,{error:'Server is not connected to Supabase yet.'});
    return send(res,500,{error:'Unable to submit BES admission.'});
  }
};
