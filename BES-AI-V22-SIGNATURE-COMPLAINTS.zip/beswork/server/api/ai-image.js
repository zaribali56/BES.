const {send,studentSession}=require('./_lib');

function imageIntent(text){
  const s=String(text||'').toLowerCase();
  return /(image|picture|pic|photo|tasveer|تصویر|پکچر|generate|create|draw|design|bana do|bana de|banado|bna do|bna de|tayyar kar|poster|logo|thumbnail|illustration|wallpaper|diagram|chart|scene|visual)/i.test(s)
    && /(bana|ban|create|generate|draw|design|photo|picture|image|tasveer|تصویر|poster|logo|thumbnail|illustration|wallpaper|diagram|chart|scene|visual)/i.test(s);
}

module.exports=async(req,res)=>{
  const session=studentSession(req);
  if(!session?.studentId) return send(res,401,{error:'Student login required.'});
  if(req.method!=='POST') return send(res,405,{error:'Method not allowed.'});
  try{
    if(!process.env.OPENAI_API_KEY) return send(res,503,{error:'Image generation is not configured yet. Add OPENAI_API_KEY in Vercel Environment Variables.'});
    const body=typeof req.body==='object'&&req.body?req.body:await new Promise((resolve,reject)=>{
      let raw='';req.on('data',c=>raw+=c);req.on('end',()=>{try{resolve(JSON.parse(raw||'{}'))}catch(e){reject(e)}});req.on('error',reject);
    });
    const prompt=String(body.prompt||'').trim();
    if(!prompt) return send(res,400,{error:'Image prompt is required.'});
    if(prompt.length>4000) return send(res,400,{error:'Image request is too long.'});

    const r=await fetch('https://api.openai.com/v1/images/generations',{
      method:'POST',
      headers:{'Authorization':'Bearer '+process.env.OPENAI_API_KEY,'Content-Type':'application/json'},
      body:JSON.stringify({
        model:process.env.OPENAI_IMAGE_MODEL||'gpt-image-1',
        prompt,
        size:'1024x1024',
        quality:process.env.OPENAI_IMAGE_QUALITY||'medium',
        output_format:'png'
      })
    });
    const data=await r.json();
    if(!r.ok){console.error('BES image API error',data);return send(res,502,{error:data?.error?.message||'Image generation failed.'});}
    const b64=data?.data?.[0]?.b64_json;
    if(!b64) return send(res,502,{error:'Image was not returned by the image service.'});
    return send(res,200,{image:`data:image/png;base64,${b64}`,model:process.env.OPENAI_IMAGE_MODEL||'gpt-image-1'});
  }catch(e){console.error('BES AI image error',e);return send(res,500,{error:'Unable to generate the image right now.'});}
};
