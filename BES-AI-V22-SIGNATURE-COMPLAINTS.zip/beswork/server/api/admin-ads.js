const { supabase, send, requireAdmin, parseBody } = require('./_lib');
module.exports=async(req,res)=>{
  if(!requireAdmin(req)) return send(res,401,{error:'Admin login required.'});
  try{
    const sb=supabase();
    if(req.method==='GET'){const {data,error}=await sb.from('ads').select('id,title,body,image_url,background_color,active,sort_order,interval_ms,created_at,updated_at').order('sort_order',{ascending:true}).order('created_at',{ascending:false});if(error)throw error;return send(res,200,{ads:data||[]});}
    const b=parseBody(req);
    if(req.method==='POST'){
      const { count: liveCount, error: countError } = await sb.from('ads').select('id', { count: 'exact', head: true }).eq('active', true);
      if(countError) throw countError;
      if((liveCount||0)>=6) return send(res,400,{error:'Maximum 6 live ads are allowed. Hide one before publishing another.'});
      const title=String(b.title||'').trim(), body=String(b.body||'').trim(), imageUrl=String(b.imageUrl||'').trim(), imageData=String(b.imageData||'').trim(), backgroundColor=String(b.backgroundColor||'#0b1824').trim();
      if(!title) return send(res,400,{error:'Ad title is required.'});
      if(imageData && !imageData.startsWith('data:image/')) return send(res,400,{error:'Invalid ad image.'});
      if(imageData.length>900000) return send(res,413,{error:'Ad image is too large.'});
      const sortOrder=Math.max(0,Math.min(999,Number(b.sortOrder||0)||0)); const intervalMs=Math.max(2000,Math.min(15000,Number(b.intervalMs||4500)||4500));
      const {data,error}=await sb.from('ads').insert({title,body,image_url:imageData||imageUrl,background_color:/^#[0-9a-fA-F]{6}$/.test(backgroundColor)?backgroundColor:'#0b1824',active:b.active!==false,sort_order:sortOrder,interval_ms:intervalMs}).select('*').single();if(error)throw error;return send(res,201,{ad:data});
    }
    const id=String(b.id||'').trim(); if(!id)return send(res,400,{error:'Ad id is required.'});
    if(req.method==='PATCH'){const patch={};if(typeof b.active==='boolean')patch.active=b.active;if(b.active===true){const {count:liveCount,error:countError}=await sb.from('ads').select('id',{count:'exact',head:true}).eq('active',true);if(countError)throw countError;if((liveCount||0)>=6)return send(res,400,{error:'Maximum 6 live ads are allowed. Hide one before publishing another.'});}if(typeof b.title==='string'&&b.title.trim())patch.title=b.title.trim();if(typeof b.sortOrder!=='undefined')patch.sort_order=Math.max(0,Math.min(999,Number(b.sortOrder)||0));if(typeof b.intervalMs!=='undefined')patch.interval_ms=Math.max(2000,Math.min(15000,Number(b.intervalMs)||4500));patch.updated_at=new Date().toISOString();const {data,error}=await sb.from('ads').update(patch).eq('id',id).select('*').maybeSingle();if(error)throw error;if(!data)return send(res,404,{error:'Ad not found.'});return send(res,200,{ad:data});}
    if(req.method==='DELETE'){const {error}=await sb.from('ads').delete().eq('id',id);if(error)throw error;return send(res,200,{ok:true});}
    return send(res,405,{error:'Method not allowed.'});
  }catch(e){console.error('admin-ads',e);return send(res,500,{error:'Unable to manage ads.'});}
};
