const { supabase, send } = require('./_lib');
module.exports=async(req,res)=>{
  if(req.method!=='GET') return send(res,405,{error:'Method not allowed.'});
  try{const sb=supabase();const {data,error}=await sb.from('ads').select('id,title,body,image_url,background_color,sort_order,interval_ms,created_at').eq('active',true).order('sort_order',{ascending:true}).order('created_at',{ascending:false}).limit(20);if(error)throw error;return send(res,200,{ads:data||[]});}
  catch(e){console.error('ads',e);return send(res,500,{error:'Unable to load announcements.'});}
};
