const {supabase,send,adminSession}=require('./_lib');
module.exports=async(req,res)=>{
  if(adminSession(req)?.role!=='admin') return send(res,401,{error:'Admin authentication required.'});
  try{
    const sb=supabase();
    const {data,error}=await sb.from('audit_logs').select('*').order('created_at',{ascending:false}).limit(200);
    if(error) throw error;
    return send(res,200,{logs:data||[]});
  }catch(e){console.error(e);return send(res,500,{error:'Unable to load audit logs.'});}
};
