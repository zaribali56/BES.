const { supabase, send } = require('./_lib');
module.exports = async (req,res) => {
  if (req.method !== 'GET') return send(res,405,{error:'Method not allowed.'});
  try {
    const sb=supabase();
    const {data,error}=await sb.from('reviews').select('id,rating,review_text,created_at,updated_at,students!inner(banned,active)').eq('active',true).eq('students.banned',false).eq('students.active',true).order('created_at',{ascending:false}).limit(100);
    if(error) throw error;
    return send(res,200,{reviews:(data||[]).map(r=>({id:r.id,rating:r.rating,review_text:r.review_text,created_at:r.created_at,updated_at:r.updated_at}))});
  } catch(e){console.error('reviews',e);return send(res,500,{error:'Unable to load reviews.'});}
};
