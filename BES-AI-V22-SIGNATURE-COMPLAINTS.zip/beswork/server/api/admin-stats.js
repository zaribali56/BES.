const {supabase,send,requireAdmin}=require('./_lib');
module.exports=async(req,res)=>{
  if(req.method!=='GET') return send(res,405,{error:'Method not allowed'});
  if(!requireAdmin(req)) return send(res,401,{error:'Admin login required.'});
  try{
    const sb=supabase();
    const {data,error}=await sb.from('students').select('class_level,active,banned,created_at');
    if(error) throw error;
    const students=data||[];
    const byClass={"9th":0,"10th":0,"11th":0,"12th":0};
    students.forEach(s=>{if(byClass[s.class_level]!=null) byClass[s.class_level]++});
    return send(res,200,{total:students.length,active:students.filter(s=>s.active).length,inactive:students.filter(s=>!s.active).length,banned:students.filter(s=>s.banned).length,byClass});
  }catch(e){console.error(e);return send(res,500,{error:'Unable to load dashboard statistics.'});}
};
