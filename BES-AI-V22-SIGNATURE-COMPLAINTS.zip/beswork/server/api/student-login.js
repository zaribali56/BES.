const {supabase,send,cookie,signSession,hashPin,safeEqualHex,parseBody}=require('./_lib');
module.exports=async(req,res)=>{
  if(req.method!=='POST') return send(res,405,{error:'Method not allowed'});
  try{
    const {studentId,pin}=parseBody(req);
    if(!studentId||!pin) return send(res,400,{error:'Student ID and PIN are required.'});
    if(!/^[A-Za-z0-9]{6,8}$/.test(String(pin).trim())) return send(res,400,{error:'PIN must be 6–8 letters/numbers.'});
    const sb=supabase();
    const {data,error}=await sb.from('students').select('id,student_id,full_name,class_level,roll_number,pin_hash,pin_salt,active').ilike('student_id',String(studentId).trim()).limit(1).maybeSingle();
    if(error) throw error;
    const s=data;
    if(!s||!s.active||!safeEqualHex(hashPin(String(pin),s.pin_salt),s.pin_hash)) return send(res,401,{error:'Student account not found or login details are incorrect.'});
    const token=signSession({type:'student',studentId:s.id});
    return send(res,200,{student:{id:s.id,studentId:s.student_id,name:s.full_name,classLevel:s.class_level,rollNumber:s.roll_number}}, {'Set-Cookie':cookie('bes_student_session',token,60*60*12)});
  }catch(e){console.error(e);return send(res,500,{error:'Server configuration error. Please contact BES administration.'});}
};
