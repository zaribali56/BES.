const {send,adminSession,parseBody}=require('./_lib');
const {changePassword}=require('./_admin-auth');
module.exports=async(req,res)=>{
  if(req.method!=='POST') return send(res,405,{error:'Method not allowed'});
  const s=adminSession(req); if(!s?.role) return send(res,401,{error:'Admin login required.'});
  try{
    const b=parseBody(req);
    const result=await changePassword(b.currentPassword,b.newPassword);
    if(!result.ok) return send(res,result.status||400,{error:result.error});
    return send(res,200,{ok:true,message:'Password changed successfully. Please log in again.'},{'Set-Cookie':require('./_lib').clearCookie('bes_admin_session')});
  }catch(e){console.error(e);return send(res,500,{error:'Unable to change password.'});}
};
