const {send,clearCookie}=require('./_lib');
module.exports=async(req,res)=>send(res,200,{ok:true},{'Set-Cookie':clearCookie('bes_student_session')});
