const { supabase, send, adminSession, parseBody } = require('./_lib');

function clean(v){ return String(v ?? '').trim(); }
function requireAdminSession(req,res){ if(adminSession(req)?.role!=='admin') return send(res,401,{error:'Admin authentication required.'}); }

module.exports = async (req,res)=>{
  try {
    if(adminSession(req)?.role!=='admin') return send(res,401,{error:'Admin authentication required.'});
    const sb = supabase();
    if(req.method==='GET'){
      const {data,error}=await sb.from('payment_settings').select('*').limit(1).maybeSingle();
      if(error) throw error;
      return send(res,200,{settings:data || {enabled:false,provider:'payfast',currency:'PKR'}});
    }
    if(req.method!=='PUT') return send(res,405,{error:'Method not allowed.'});
    const b=parseBody(req);
    const row={
      id: b.id || undefined,
      enabled: !!b.enabled,
      admission_fee: Math.max(0, Number(b.admissionFee||0)),
      currency: clean(b.currency||'PKR').toUpperCase().slice(0,8),
      provider: clean(b.provider||'payfast').toLowerCase(),
      bank_name: clean(b.bankName),
      account_title: clean(b.accountTitle),
      iban: clean(b.iban),
      account_number: clean(b.accountNumber),
      instructions: clean(b.instructions),
      updated_at: new Date().toISOString()
    };
    delete row.id;
    const {data,error}=await sb.from('payment_settings').upsert(row,{onConflict:'singleton_key'}).select('*').single();
    if(error) throw error;
    return send(res,200,{settings:data});
  } catch(e){
    console.error('admin-payments',e);
    return send(res,500,{error:'Unable to load/save payment settings.'});
  }
};
