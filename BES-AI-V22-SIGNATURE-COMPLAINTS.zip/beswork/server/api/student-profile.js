const { supabase, send, studentSession, parseBody } = require('./_lib');

module.exports = async (req, res) => {
  const session = studentSession(req);
  if (!session?.studentId) return send(res, 401, { error: 'Student login required.' });
  try {
    const sb = supabase();
    if (req.method === 'GET') {
      const { data, error } = await sb.from('students').select('id,student_id,full_name,class_level,roll_number,email,age,subjects,profile_photo,profile_completed,active,banned,created_at').eq('id', session.studentId).maybeSingle();
      if (error) throw error;
      if (!data || !data.active || data.banned) return send(res, 403, { error: 'Account is inactive or banned.' });
      return send(res, 200, { student: data });
    }
    if (req.method !== 'PATCH') return send(res, 405, { error: 'Method not allowed.' });
    const b = parseBody(req), patch = {};
    if (typeof b.name === 'string' && b.name.trim()) patch.full_name = b.name.trim();
    if (typeof b.age !== 'undefined' && String(b.age).trim() !== '') { const n = Number(b.age); if (!Number.isInteger(n) || n < 5 || n > 100) return send(res, 400, { error: 'Invalid age.' }); patch.age = n; }
    if (typeof b.classLevel === 'string' && b.classLevel) { if (!['9th','10th','11th','12th'].includes(b.classLevel)) return send(res, 400, { error: 'Invalid class.' }); patch.class_level = b.classLevel; }
    if (typeof b.rollNumber === 'string') patch.roll_number = b.rollNumber.trim() || null;
    if (typeof b.email === 'string' && b.email.trim()) { const email = b.email.trim().toLowerCase(); if (!/^\S+@\S+\.\S+$/.test(email)) return send(res, 400, { error: 'Invalid email.' }); patch.email = email; }
    if (typeof b.subjects === 'string') patch.subjects = b.subjects.trim();
    if (typeof b.profilePhoto === 'string' && b.profilePhoto) { if (!b.profilePhoto.startsWith('data:image/') || b.profilePhoto.length > 700000) return send(res, 400, { error: 'Invalid or oversized profile photo.' }); patch.profile_photo = b.profilePhoto; }
    if (!Object.keys(patch).length) return send(res, 400, { error: 'No changes supplied.' });
    const { data: current, error: currentError } = await sb.from('students').select('full_name,class_level,roll_number,age,subjects').eq('id', session.studentId).maybeSingle();
    if (currentError) throw currentError;
    const merged = { ...(current || {}), ...patch };
    if (!merged.full_name || !merged.class_level || !merged.roll_number || merged.age == null || !String(merged.subjects || '').trim()) {
      return send(res, 400, { error: 'Please complete name, age, class, roll number and subjects. Photo is optional.' });
    }
    patch.profile_completed = true;
    const { data, error } = await sb.from('students').update(patch).eq('id', session.studentId).select('id,student_id,full_name,class_level,roll_number,email,age,subjects,profile_photo,profile_completed,active,banned,created_at').single();
    if (error?.code === '23505') return send(res, 409, { error: 'That email, class or roll number is already in use.' });
    if (error) throw error;
    return send(res, 200, { student: data });
  } catch (e) { console.error('student-profile', e); return send(res, 500, { error: 'Unable to update your profile.' }); }
};
