const {supabase,send,requireAdmin,parseBody,hashPin}=require('./_lib');
const crypto=require('crypto');
function makeId(){return 'BES-'+new Date().getFullYear()+'-'+crypto.randomBytes(4).toString('hex').toUpperCase();}
module.exports=async(req,res)=>{
  if(!requireAdmin(req)) return send(res,401,{error:'Admin login required.'});
  const sb=supabase();
  try{
    if(req.method==='GET'){
      const {data,error}=await sb.from('students').select('id,student_id,full_name,class_level,roll_number,email,age,subjects,profile_photo,profile_completed,active,banned,created_at').order('class_level').order('roll_number');
      if(error) throw error; return send(res,200,{students:data||[]});
    }
    if(req.method==='POST'){
      const {name,classLevel,rollNumber,pin}=parseBody(req);
      if(!name||!classLevel||!rollNumber||!pin) return send(res,400,{error:'Name, class, roll number and PIN are required.'});
      if(!['9th','10th','11th','12th'].includes(String(classLevel))) return send(res,400,{error:'Please select a valid class.'});
      if(!/^[A-Za-z0-9]{6,8}$/.test(String(pin))) return send(res,400,{error:'PIN must be 6–8 letters/numbers.'});
      const salt=crypto.randomBytes(16).toString('hex'); const pinHash=hashPin(String(pin),salt); const studentId=makeId();
      const {data,error}=await sb.from('students').insert({student_id:studentId,full_name:String(name).trim(),class_level:String(classLevel),roll_number:String(rollNumber).trim(),pin_hash:pinHash,pin_salt:salt,active:true,banned:false,profile_completed:false}).select('id,student_id,full_name,class_level,roll_number,active,banned,created_at').single();
      if(error) return send(res,500,{error:error.code==='23505'?'A student with this class and roll number already exists.':'Unable to save student.'});
      return send(res,201,{student:data});
    }
    return send(res,405,{error:'Method not allowed'});
  }catch(e){console.error(e);return send(res,500,{error:'Unable to save student.'});}
};
