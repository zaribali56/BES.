const {supabase,send,requireAdmin,parseBody}=require('./_lib');
module.exports=async(req,res)=>{
  if(!requireAdmin(req)) return send(res,401,{error:'Admin login required.'});
  const id=req.query?.id; if(!id) return send(res,400,{error:'Student id is required.'});
  try{
    const sb=supabase();
    if(req.method==='PATCH'){
      const b=parseBody(req), patch={};
      if(typeof b.active!=='undefined') patch.active=Boolean(b.active);
      if(typeof b.banned!=='undefined') { patch.banned=Boolean(b.banned); if(Boolean(b.banned)) patch.active=false; }
      if(typeof b.name==='string'&&b.name.trim()) patch.full_name=b.name.trim();
      if(typeof b.classLevel==='string'&&['9th','10th','11th','12th'].includes(b.classLevel)) patch.class_level=b.classLevel;
      if(typeof b.rollNumber==='string'&&b.rollNumber.trim()) patch.roll_number=b.rollNumber.trim();
      if(typeof b.age!=='undefined'&&String(b.age).trim()!==''){const n=Number(b.age);if(!Number.isInteger(n)||n<5||n>100)return send(res,400,{error:'Invalid age.'});patch.age=n;}
      if(typeof b.email==='string'&&b.email.trim())patch.email=b.email.trim().toLowerCase();
      if(typeof b.subjects==='string')patch.subjects=b.subjects.trim();
      if(typeof b.profilePhoto==='string'&&b.profilePhoto){if(!b.profilePhoto.startsWith('data:image/')||b.profilePhoto.length>700000)return send(res,400,{error:'Invalid profile photo.'});patch.profile_photo=b.profilePhoto;}
      if(!Object.keys(patch).length)return send(res,400,{error:'No valid changes supplied.'});
      const {data,error}=await sb.from('students').update(patch).eq('id',id).select('id,student_id,full_name,class_level,roll_number,email,age,subjects,profile_photo,profile_completed,active,banned,created_at').single();
      if(error?.code==='23505')return send(res,409,{error:'That email, class or roll number is already in use.'});
      if(error?.code==='PGRST116')return send(res,404,{error:'Student not found.'}); if(error)throw error; return send(res,200,{student:data});
    }
    if(req.method==='DELETE'){const {error}=await sb.from('students').delete().eq('id',id);if(error)throw error;return send(res,200,{ok:true});}
    return send(res,405,{error:'Method not allowed'});
  }catch(e){console.error(e);return send(res,500,{error:'Unable to update student.'});}
};
