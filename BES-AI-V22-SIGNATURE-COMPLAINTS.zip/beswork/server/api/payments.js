const { supabase, send, studentSession, parseBody } = require('./_lib');

function nowIso(){ return new Date().toISOString(); }

module.exports = async (req,res)=>{
  try{
    const sb=supabase();
    if(req.method==='GET'){
      const {data,error}=await sb.from('payment_settings').select('enabled,admission_fee,currency,provider,bank_name,account_title,iban,account_number,instructions').limit(1).maybeSingle();
      if(error) throw error;
      return send(res,200,{settings:data || {enabled:false,admission_fee:0,currency:'PKR',provider:'payfast'}});
    }
    if(req.method!=='POST') return send(res,405,{error:'Method not allowed.'});
    const b=parseBody(req);
    const student=studentSession(req);
    const settingsRes=await sb.from('payment_settings').select('*').limit(1).maybeSingle();
    if(settingsRes.error) throw settingsRes.error;
    const settings=settingsRes.data;
    if(!settings?.enabled) return send(res,409,{error:'Online admission payment is currently disabled.'});
    const amount=Number(b.amount ?? settings.admission_fee);
    if(!Number.isFinite(amount) || amount <= 0) return send(res,400,{error:'A valid admission fee is required.'});
    const ref='BES-'+Date.now().toString(36).toUpperCase();
    const {data,error}=await sb.from('payments').insert({
      student_id: student?.studentId || null,
      reference: ref,
      purpose: 'admission',
      amount,
      currency: settings.currency||'PKR',
      provider: settings.provider||'payfast',
      status: 'pending',
      customer_email: b.email ? String(b.email).trim().toLowerCase() : null,
      customer_phone: b.phone ? String(b.phone).trim() : null,
      metadata: { name: b.name || null, admission_fee: amount, created_from:'BES admission' },
      created_at: nowIso(),
      updated_at: nowIso()
    }).select('*').single();
    if(error) throw error;

    // Live gateway activation requires approved merchant credentials.
    // For safe testing we return a hosted-checkout placeholder URL only when configured.
    const checkoutUrl = process.env.PAYFAST_CHECKOUT_URL || '';
    if(checkoutUrl){
      const u=new URL(checkoutUrl);
      u.searchParams.set('reference',ref);
      u.searchParams.set('amount',String(amount));
      u.searchParams.set('currency',settings.currency||'PKR');
      return send(res,201,{payment:data,checkoutUrl:u.toString(),message:'Payment session created.'});
    }
    return send(res,201,{payment:data,checkoutUrl:null,manualBankTransfer:{bankName:settings.bank_name,accountTitle:settings.account_title,iban:settings.iban,accountNumber:settings.account_number,instructions:settings.instructions},message:'Payment is recorded as pending. Configure the approved PayFast merchant checkout URL/credentials to enable live checkout.'});
  }catch(e){
    console.error('payments',e);
    return send(res,500,{error:'Unable to create payment session.'});
  }
};
