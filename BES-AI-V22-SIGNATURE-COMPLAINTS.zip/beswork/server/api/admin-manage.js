const crypto=require('crypto');
const {supabase,send,adminSession,parseBody,hashPin,signSession}=require('./_lib');

const DEFAULT_PERMS=['students.view','students.edit','students.delete','students.ban','materials.manage','tests.manage','results.manage','reviews.manage','ads.manage','website.manage','payments.manage','audit.view'];

async function audit(sb,session,action,targetType,targetId,details={}){
  await sb.from('audit_logs').insert({actor_type:'admin',actor_id:session.adminId,action,target_type:targetType,target_id:String(targetId||''),details});
}
function isSuper(s){return s?.role==='super_admin';}
module.exports=async(req,res)=>{
  const session=adminSession(req);
  if(!session?.adminId) return send(res,401,{error:'Admin authentication required.'});
  try{
    const sb=supabase();
    const {data:me,error:meErr}=await sb.from('admin_accounts').select('id,email,full_name,role,permissions,active').eq('id',session.adminId).maybeSingle();
    if(meErr) throw meErr;
    if(!me?.active) return send(res,403,{error:'Admin account is disabled.'});
    if(req.method==='GET'){
      if(!isSuper(me)) return send(res,403,{error:'Super Admin permission required.'});
      const {data,error}=await sb.from('admin_accounts').select('id,email,full_name,role,permissions,active,created_at,updated_at').order('created_at');
      if(error) throw error;
      return send(res,200,{admins:data||[],currentAdmin:me});
    }
    if(!isSuper(me)) return send(res,403,{error:'Only the Super Admin can manage administrators.'});
    const b=parseBody(req);
    if(req.method==='POST'){
      const email=String(b.email||'').trim().toLowerCase();
      const password=String(b.password||'');
      const fullName=String(b.fullName||'').trim();
      const permissions=Array.isArray(b.permissions)?b.permissions.filter(x=>DEFAULT_PERMS.includes(x)):[];
      if(!email||!password) return send(res,400,{error:'Email and password are required.'});
      if(password.length<8) return send(res,400,{error:'Admin password must be at least 8 characters.'});
      const salt=crypto.randomBytes(16).toString('hex');
      const passwordHash=hashPin(password,salt);
      const {data,error}=await sb.from('admin_accounts').insert({email,password_hash:passwordHash,password_salt:salt,full_name:fullName||null,role:'admin',permissions,active:true,created_by:me.id}).select('id,email,full_name,role,permissions,active,created_at').single();
      if(error){if(error.code==='23505') return send(res,409,{error:'An admin with this email already exists.'});throw error;}
      await audit(sb,me,'admin.created','admin',data.id,{email:data.email,permissions});
      return send(res,201,{admin:data});
    }
    if(req.method==='PATCH'){
      const id=String(b.id||'');
      if(!id) return send(res,400,{error:'Admin ID is required.'});
      if(id===me.id && b.active===false) return send(res,400,{error:'The Super Admin cannot disable their own account.'});
      const updates={};
      if(typeof b.fullName==='string') updates.full_name=b.fullName.trim()||null;
      if(Array.isArray(b.permissions)) updates.permissions=b.permissions.filter(x=>DEFAULT_PERMS.includes(x));
      if(typeof b.active==='boolean' && id!==me.id) updates.active=b.active;
      if(typeof b.password==='string' && b.password){
        if(b.password.length<8) return send(res,400,{error:'Admin password must be at least 8 characters.'});
        const salt=crypto.randomBytes(16).toString('hex'); updates.password_salt=salt; updates.password_hash=hashPin(b.password,salt);
      }
      if(Object.keys(updates).length===0) return send(res,400,{error:'No changes supplied.'});
      const {data,error}=await sb.from('admin_accounts').update({...updates,updated_at:new Date().toISOString()}).eq('id',id).eq('role','admin').select('id,email,full_name,role,permissions,active,created_at,updated_at').maybeSingle();
      if(error) throw error;
      if(!data) return send(res,404,{error:'Admin not found or cannot be modified.'});
      await audit(sb,me,'admin.updated','admin',id,{changes:Object.keys(updates)});
      return send(res,200,{admin:data});
    }
    if(req.method==='DELETE'){
      const id=String(b.id||'');
      if(!id || id===me.id) return send(res,400,{error:'The Super Admin cannot be removed.'});
      const {data,error}=await sb.from('admin_accounts').update({active:false,updated_at:new Date().toISOString()}).eq('id',id).eq('role','admin').select('id,email,full_name,role,active').maybeSingle();
      if(error) throw error;
      if(!data) return send(res,404,{error:'Admin not found.'});
      await audit(sb,me,'admin.removed','admin',id,{email:data.email});
      return send(res,200,{ok:true,admin:data});
    }
    return send(res,405,{error:'Method not allowed.'});
  }catch(e){console.error(e);return send(res,500,{error:'Unable to manage administrators.'});}
};
