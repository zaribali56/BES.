const {supabase,send,adminSession,parseBody}=require('./_lib');
module.exports=async(req,res)=>{
  if(adminSession(req)?.role!=='admin') return send(res,401,{error:'Admin authentication required.'});
  try{
    const sb=supabase();
    if(req.method==='GET'){
      const {data,error}=await sb.from('admin_permissions').select('*').order('permission_key');
      if(error) throw error;
      return send(res,200,{permissions:data||[]});
    }
    if(req.method!=='PUT') return send(res,405,{error:'Method not allowed.'});
    const b=parseBody(req);
    const updates=Array.isArray(b.permissions)?b.permissions:[];
    for(const x of updates){
      if(!x?.permission_key) continue;
      const {error}=await sb.from('admin_permissions').upsert({permission_key:String(x.permission_key),enabled:!!x.enabled,updated_at:new Date().toISOString()},{onConflict:'permission_key'});
      if(error) throw error;
    }
    const {data,error}=await sb.from('admin_permissions').select('*').order('permission_key');
    if(error) throw error;
    return send(res,200,{permissions:data||[]});
  }catch(e){console.error(e);return send(res,500,{error:'Unable to save permissions.'});}
};
