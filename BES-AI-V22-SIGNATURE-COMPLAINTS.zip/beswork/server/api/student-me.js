const {supabase,send,studentSession}=require('./_lib');
module.exports=async(req,res)=>{
  if(req.method!=='GET')return send(res,405,{error:'Method not allowed'});
  const session=studentSession(req);if(!session?.studentId)return send(res,401,{error:'Not signed in.'});
  try{const sb=supabase();const {data:student,error:e1}=await sb.from('students').select('id,student_id,full_name,class_level,roll_number,email,age,subjects,profile_photo,profile_completed,active,banned,created_at').eq('id',session.studentId).maybeSingle();if(e1)throw e1;if(!student||!student.active||student.banned)return send(res,401,{error:student?.banned?'Account is banned.':'Account is inactive.'});const {data:results,error:e2}=await sb.from('results').select('id,title,subject,marks,total_marks,percentage,grade,created_at').eq('student_id',session.studentId).order('created_at',{ascending:false}).limit(20);if(e2)throw e2;return send(res,200,{student,results:results||[]});}catch(e){console.error(e);return send(res,500,{error:'Unable to load student dashboard.'});}
};
