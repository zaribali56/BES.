const { send } = require('./_lib');

module.exports = async (req, res) => {
  if (req.method !== 'GET') return send(res, 405, { ok: false, error: 'Method not allowed.' });
  return send(res, 200, {
    ok: true,
    service: 'BES API',
    signupRoute: '/api/student-signup',
    configured: Boolean(process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY)
  });
};
