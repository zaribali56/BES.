const { supabase, send, studentSession, parseBody } = require('./_lib');
module.exports = async (req,res) => {
  const session=studentSession(req); if(!session?.studentId) return send(res,401,{error:'Student login required.'});
  try {
    const sb=supabase();
    const {data:student,error:se}=await sb.from('students').select('active,banned').eq('id',session.studentId).maybeSingle();
    if(se) throw se; if(!student||!student.active||student.banned) return send(res,403,{error:'Your account cannot submit reviews.'});
    if(req.method==='GET'){
      const {data,error}=await sb.from('reviews').select('id,rating,review_text,active,created_at,updated_at').eq('student_id',session.studentId).maybeSingle();
      if(error) throw error; return send(res,200,{review:data||null});
    }
    if(req.method!=='POST') return send(res,405,{error:'Method not allowed.'});
    const b=parseBody(req), rating=Number(b.rating), text=String(b.reviewText||'').trim();
    if(!Number.isInteger(rating)||rating<1||rating>5) return send(res,400,{error:'Please select a rating from 1 to 5.'});
    if(text.length<5||text.length>800) return send(res,400,{error:'Review must be between 5 and 800 characters.'});
    const {data:existing}=await sb.from('reviews').select('id').eq('student_id',session.studentId).maybeSingle();
    let data,error;
    if(existing){({data,error}=await sb.from('reviews').update({rating,review_text:text,active:true,updated_at:new Date().toISOString()}).eq('id',existing.id).select('id,rating,review_text,active,created_at,updated_at').single());}
    else {({data,error}=await sb.from('reviews').insert({student_id:session.studentId,rating,review_text:text,active:true}).select('id,rating,review_text,active,created_at,updated_at').single());}
    if(error) throw error; return send(res,200,{review:data});
  }catch(e){console.error('my-review',e);return send(res,500,{error:'Unable to save your review.'});}
};
