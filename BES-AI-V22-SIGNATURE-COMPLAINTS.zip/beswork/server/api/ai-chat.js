const {supabase,send,studentSession,parseBody}=require('./_lib');
module.exports=async(req,res)=>{
 const session=studentSession(req); if(!session?.studentId) return send(res,401,{error:'Student login required.'});
 try{
  const sb=supabase();
  if(req.method==='GET'){
   const {data,error}=await sb.from('ai_messages').select('id,role,content,mode,attachment_name,created_at').eq('student_id',session.studentId).order('created_at',{ascending:true}).limit(300);
   if(error) throw error; return send(res,200,{messages:data||[]});
  }
  if(req.method==='POST'){
   const b=parseBody(req); const role=String(b.role||'').trim(); const content=String(b.content||'').trim();
   if(!['user','assistant'].includes(role)||!content) return send(res,400,{error:'Invalid chat message.'});
   if(content.length>12000) return send(res,400,{error:'Message is too long.'});
   const {data,error}=await sb.from('ai_messages').insert({student_id:session.studentId,role,content,mode:String(b.mode||'normal').slice(0,30),attachment_name:String(b.attachmentName||'').slice(0,255)}).select('id,role,content,mode,attachment_name,created_at').single();
   if(error) throw error; return send(res,201,{message:data});
  }
  return send(res,405,{error:'Method not allowed.'});
 }catch(e){console.error('BES AI chat error',e);return send(res,500,{error:'Unable to save/load BES-AI chat.'});}
};
