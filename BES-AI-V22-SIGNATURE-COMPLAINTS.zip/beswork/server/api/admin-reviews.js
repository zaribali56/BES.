const { supabase, send, requireAdmin, parseBody } = require('./_lib');
module.exports = async (req,res) => {
  if(!requireAdmin(req)) return send(res,401,{error:'Admin login required.'});
  try{
    const sb=supabase();
    if(req.method==='GET'){
      const {data,error}=await sb.from('reviews').select('id,rating,review_text,active,created_at,updated_at,students(id,student_id,full_name,class_level,roll_number,email,age,banned,active)').order('created_at',{ascending:false}).limit(500);
      if(error) throw error; return send(res,200,{reviews:data||[]});
    }
    const b=parseBody(req), id=String(b.id||'').trim(); if(!id) return send(res,400,{error:'Review id is required.'});
    if(req.method==='PATCH'){
      if(typeof b.active!=='boolean') return send(res,400,{error:'Review active state is required.'});
      const {data,error}=await sb.from('reviews').update({active:b.active,updated_at:new Date().toISOString()}).eq('id',id).select('id,active').maybeSingle();
      if(error) throw error; if(!data) return send(res,404,{error:'Review not found.'}); return send(res,200,{review:data});
    }
    if(req.method==='DELETE'){
      const {error}=await sb.from('reviews').delete().eq('id',id); if(error) throw error; return send(res,200,{ok:true});
    }
    return send(res,405,{error:'Method not allowed.'});
  }catch(e){console.error('admin-reviews',e);return send(res,500,{error:'Unable to manage reviews.'});}
};
