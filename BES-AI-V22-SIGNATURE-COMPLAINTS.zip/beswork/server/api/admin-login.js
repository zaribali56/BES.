const {send,cookie,signSession,parseBody}=require('./_lib');
const {verifyAdmin}=require('./_admin-auth');
module.exports=async(req,res)=>{
  if(req.method!=='POST') return send(res,405,{error:'Method not allowed'});
  try{
    const {email,password}=parseBody(req);
    const result=await verifyAdmin(email,password);
    if(!result.ok) return send(res,401,{error:result.error});
    const token=signSession({type:'admin',role:'admin',adminId:result.account.id});
    return send(res,200,{ok:true,admin:{id:result.account.id,email:result.account.email,fullName:result.account.full_name||'',role:result.account.role||'super_admin',permissions:result.account.permissions||[]}},{'Set-Cookie':cookie('bes_admin_session',token,60*60*12)});
  }catch(e){console.error(e);return send(res,500,{error:'Admin login is not configured. Run the BES database migration first.'});}
};
