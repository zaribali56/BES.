const {supabase,send,studentSession,parseBody}=require('./_lib');
module.exports=async(req,res)=>{
 const session=studentSession(req); if(!session?.studentId) return send(res,401,{error:'Student authentication required.'});
 try{const sb=supabase();
  if(req.method==='GET'){
   const {data,error}=await sb.from('complaints').select('id,subject,status,created_at,updated_at,complaint_messages(id,sender_type,message,attachment_data,attachment_name,created_at)').eq('student_id',session.studentId).order('created_at',{ascending:false});
   if(error) throw error;
   return send(res,200,{complaints:(data||[]).map(c=>({...c,complaint_messages:(c.complaint_messages||[]).sort((a,b)=>new Date(a.created_at)-new Date(b.created_at))}))});
  }
  if(req.method==='POST'){
   const b=parseBody(req); const subject=String(b.subject||'').trim(); const message=String(b.message||'').trim();
   if(subject.length<3||subject.length>160) return send(res,400,{error:'Subject must be between 3 and 160 characters.'});
   if(message.length<3||message.length>3000) return send(res,400,{error:'Complaint message must be between 3 and 3000 characters.'});
   let attachmentData=null,attachmentName=null;
   if(b.attachmentData){attachmentData=String(b.attachmentData);attachmentName=String(b.attachmentName||'attachment');if(!/^data:image\/(png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=]+$/.test(attachmentData)||attachmentData.length>900000)return send(res,400,{error:'Please attach a valid image under 650 KB.'});}
   const {data:c,error:e1}=await sb.from('complaints').insert({student_id:session.studentId,subject,status:'pending'}).select('id,subject,status,created_at,updated_at').single(); if(e1) throw e1;
   const {data:m,error:e2}=await sb.from('complaint_messages').insert({complaint_id:c.id,sender_type:'student',sender_id:session.studentId,message,attachment_data:attachmentData,attachment_name:attachmentName}).select('id,sender_type,message,attachment_data,attachment_name,created_at').single(); if(e2) throw e2;
   return send(res,201,{complaint:{...c,complaint_messages:[m]}});
  }
  if(req.method==='PATCH'){
   const b=parseBody(req); const id=String(b.id||''); const message=String(b.message||'').trim(); if(!id||message.length<1||message.length>3000)return send(res,400,{error:'Complaint ID and reply message are required.'});
   const {data:c,error:e}=await sb.from('complaints').select('id,status').eq('id',id).eq('student_id',session.studentId).maybeSingle(); if(e)throw e;if(!c)return send(res,404,{error:'Complaint not found.'});
   if(c.status==='resolved')return send(res,400,{error:'This complaint is resolved and cannot receive new replies.'});
   const {data:m,error:e2}=await sb.from('complaint_messages').insert({complaint_id:id,sender_type:'student',sender_id:session.studentId,message}).select('id,sender_type,message,attachment_data,attachment_name,created_at').single();if(e2)throw e2;
   await sb.from('complaints').update({status:'pending',updated_at:new Date().toISOString()}).eq('id',id).eq('student_id',session.studentId);
   return send(res,201,{message:m});
  }
  return send(res,405,{error:'Method not allowed.'});
 }catch(e){console.error(e);return send(res,500,{error:'Unable to process complaint.'});}
};
