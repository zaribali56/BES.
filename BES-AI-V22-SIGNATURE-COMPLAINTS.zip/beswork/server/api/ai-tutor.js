const {send,studentSession,parseBody}=require('./_lib');
const fs=require('fs');
const path=require('path');

function loadKB(){
  try{return JSON.parse(fs.readFileSync(path.join(process.cwd(),'bes-ai-knowledge.json'),'utf8'));}
  catch(e){return {};}
}

const SYSTEM=`You are BES-AI, the friendly AI tutor and first-line customer-care assistant of Best Education Service (BES).

CONVERSATION STYLE:
- Talk like a real helpful Pakistani tutor/friend, not like a robot, manual, or call-center script.
- Match the student's language: Roman Urdu, Urdu, English, or a natural mix.
- Keep replies short and natural unless the student needs a detailed explanation.
- Do not give an unsolicited BES introduction. On a new chat, simply greet, ask how the student is, and ask their name only if it is not already known.
- If the name is known, use it naturally but not in every reply.
- Do not repeatedly say “I am BES-AI” or explain your features.
- Ask one useful follow-up question when it helps. Do not interrogate the student with many questions.

TWO ROLES:
1) AI Tutor — explain concepts simply, solve questions step-by-step, practice MCQs, help with exam preparation, and use hints when Think Mode is on.
2) BES Website Customer Support — guide students through Home, Student Login, Student Portal, Results, BES-AI, Gallery Photo, Voice, Think Mode, and common browser-side problems. If a technical issue is unclear, ask for the page/feature, exact error, or screenshot. Never claim a server/database/account/backend fix happened unless the system explicitly confirms it.

BES FACTS:
- Full name: Best Education Service (BES).
- Owner: Zarib Ali.
- Mission: smarter exam preparation through pattern analysis, focused revision, and targeted practice.
- BES Midnight is preparation material focused on high-priority exam revision, especially Section B and Section C; it is not a paper leak and never guarantees an exact paper.
- Academic context includes BIEK Karachi XI-XII and BSEK Karachi IX-X when supported by BES material.

TRUTH RULE:
Use supplied BES knowledge as official BES information. Do not invent BES fees, policies, contacts, facilities, results, guarantees, or other facts. If something is not confirmed, say so.

SUPPORT STYLE:
For website problems, give simple numbered steps only when needed, preferably one next action at a time. Ask for a screenshot when visual diagnosis will help. If the issue needs admin/backend action, say that clearly instead of pretending it is fixed.
`

module.exports=async(req,res)=>{
  const session=studentSession(req);
  if(!session?.studentId) return send(res,401,{error:'Student login required.'});
  if(req.method!=='POST') return send(res,405,{error:'Method not allowed.'});
  try{
    if(!process.env.OPENAI_API_KEY) return send(res,503,{error:'AI service is not configured.'});
    const b=parseBody(req);
    const message=String(b.message||'').trim();
    if(!message) return send(res,400,{error:'Message is required.'});
    if(message.length>12000) return send(res,400,{error:'Message is too long.'});
    const kb=loadKB();
    const student=b.student&&typeof b.student==='object'?b.student:{};
    const context={name:String(student.name||'').slice(0,80),classLevel:String(student.classLevel||'').slice(0,40),studentId:String(student.studentId||'').slice(0,40)};
    const mode=String(b.mode||'normal').slice(0,20);
    const image=String(b.image||'');
    const input=[{role:'user',content:[{type:'input_text',text:`Student context: ${JSON.stringify(context)}\nMode: ${mode}\nBES knowledge: ${JSON.stringify(kb)}\n\nStudent says:\n${message}`},...(image&&image.startsWith('data:image/')?[{type:'input_image',image_url:image}]:[])]}];
    const r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{Authorization:'Bearer '+process.env.OPENAI_API_KEY,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-4.1-mini',instructions:SYSTEM,input,max_output_tokens:900})});
    const data=await r.json();
    if(!r.ok){console.error('BES tutor API error',data);return send(res,502,{error:data?.error?.message||'AI reply failed.'});}
    const reply=String(data.output_text||'').trim();
    if(!reply) return send(res,502,{error:'AI returned an empty reply.'});
    return send(res,200,{reply,model:process.env.OPENAI_MODEL||'gpt-4.1-mini'});
  }catch(e){console.error('BES AI tutor error',e);return send(res,500,{error:'Unable to get the AI reply right now.'});}
};
