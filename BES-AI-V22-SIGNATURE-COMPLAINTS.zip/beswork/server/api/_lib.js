const crypto = require('crypto');
const { createClient } = require('@supabase/supabase-js');

function supabase(){
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if(!url || !key) throw new Error('Supabase environment variables are not configured');
  return createClient(url, key, { auth: { autoRefreshToken: false, persistSession: false } });
}
function send(res,status,body,extraHeaders={}){
  res.status(status);
  Object.entries({ 'Content-Type':'application/json', 'Cache-Control':'no-store', ...extraHeaders }).forEach(([k,v])=>res.setHeader(k,v));
  return res.json(body);
}
function cookie(name,value,maxAge){
  return `${name}=${encodeURIComponent(value)}; Path=/; Max-Age=${maxAge}; HttpOnly; Secure; SameSite=Lax`;
}
function clearCookie(name){ return cookie(name,'',0); }
function b64url(v){ return Buffer.from(v).toString('base64url'); }
function signSession(payload){
  const secret = process.env.SESSION_SECRET;
  if(!secret) throw new Error('SESSION_SECRET is not configured');
  const body = b64url(JSON.stringify({ ...payload, exp: Math.floor(Date.now()/1000)+60*60*12 }));
  const sig = crypto.createHmac('sha256', secret).update(body).digest('base64url');
  return `${body}.${sig}`;
}
function readCookie(req,name){
  const raw = req.headers.cookie || '';
  const part = raw.split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='));
  return part ? decodeURIComponent(part.slice(name.length+1)) : null;
}
function verifySession(token){
  try{
    if(!token || !process.env.SESSION_SECRET) return null;
    const [body,sig] = token.split('.');
    if(!body || !sig) return null;
    const expected = crypto.createHmac('sha256', process.env.SESSION_SECRET).update(body).digest('base64url');
    const a=Buffer.from(sig), b=Buffer.from(expected);
    if(a.length!==b.length || !crypto.timingSafeEqual(a,b)) return null;
    const data = JSON.parse(Buffer.from(body,'base64url').toString('utf8'));
    if(!data.exp || data.exp < Math.floor(Date.now()/1000)) return null;
    return data;
  }catch(e){ return null; }
}
function studentSession(req){ return verifySession(readCookie(req,'bes_student_session')); }
function adminSession(req){ return verifySession(readCookie(req,'bes_admin_session')); }
function hashPin(pin,salt){ return crypto.scryptSync(pin,salt,64).toString('hex'); }
function safeEqualHex(a,b){
  try { const aa=Buffer.from(a,'hex'), bb=Buffer.from(b,'hex'); return aa.length===bb.length && crypto.timingSafeEqual(aa,bb); } catch(e){ return false; }
}
function parseBody(req){
  if(req.body && typeof req.body === 'object') return req.body;
  try{return JSON.parse(req.body||'{}')}catch(e){return {}};
}
function requireAdmin(req){ return adminSession(req)?.role==='admin'; }
module.exports={supabase,send,cookie,clearCookie,signSession,verifySession,studentSession,adminSession,hashPin,safeEqualHex,parseBody,requireAdmin};
