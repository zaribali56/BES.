-- BES Admin + payments + audit + admissions configuration
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS public.payment_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  singleton_key text UNIQUE NOT NULL DEFAULT 'default',
  enabled boolean NOT NULL DEFAULT false,
  admission_fee numeric(12,2) NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'PKR',
  provider text NOT NULL DEFAULT 'payfast',
  bank_name text,
  account_title text,
  iban text,
  account_number text,
  instructions text,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.payment_settings ADD COLUMN IF NOT EXISTS singleton_key text;
UPDATE public.payment_settings SET singleton_key='default' WHERE singleton_key IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS idx_payment_settings_singleton ON public.payment_settings(singleton_key);

CREATE TABLE IF NOT EXISTS public.payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES public.students(id) ON DELETE SET NULL,
  reference text UNIQUE NOT NULL,
  purpose text NOT NULL DEFAULT 'admission',
  amount numeric(12,2) NOT NULL,
  currency text NOT NULL DEFAULT 'PKR',
  provider text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','failed','cancelled','refunded')),
  customer_email text,
  customer_phone text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_payments_status_created ON public.payments(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_payments_student ON public.payments(student_id, created_at DESC);

CREATE TABLE IF NOT EXISTS public.audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_type text NOT NULL DEFAULT 'admin',
  actor_id uuid,
  action text NOT NULL,
  target_type text,
  target_id text,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audit_logs_time ON public.audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_target ON public.audit_logs(target_type,target_id,created_at DESC);

CREATE TABLE IF NOT EXISTS public.admin_permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  permission_key text UNIQUE NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO public.admin_permissions(permission_key,enabled)
VALUES
('students.view',true),('students.edit',true),('students.delete',true),('students.ban',true),
('materials.manage',true),('tests.manage',true),('results.manage',true),('reviews.manage',true),
('ads.manage',true),('website.manage',true),('website.redesign',false),('payments.manage',true),
('admin.security',true),('audit.view',true)
ON CONFLICT(permission_key) DO NOTHING;

CREATE TABLE IF NOT EXISTS public.admission_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  singleton_key text UNIQUE NOT NULL DEFAULT 'default',
  mode text NOT NULL DEFAULT 'free' CHECK (mode IN ('free','paid')),
  fee numeric(12,2) NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'PKR',
  phone_otp_enabled boolean NOT NULL DEFAULT false,
  email_unique boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO public.admission_settings(singleton_key,mode,fee,currency,phone_otp_enabled,email_unique)
VALUES('default','free',0,'PKR',false,true)
ON CONFLICT(singleton_key) DO NOTHING;

-- Student identity/admission fields
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS address text;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS father_phone text;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS phone_verified boolean NOT NULL DEFAULT false;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS admission_date timestamptz NOT NULL DEFAULT now();
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS current_academic_year integer;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS qr_token text UNIQUE;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS archived boolean NOT NULL DEFAULT false;
CREATE INDEX IF NOT EXISTS idx_students_phone ON public.students(phone);
CREATE INDEX IF NOT EXISTS idx_students_admission_date ON public.students(admission_date DESC);

-- Keep AI history private to its student account; server APIs should enforce session ownership.
ALTER TABLE public.ai_messages ENABLE ROW LEVEL SECURITY;


-- Multi-admin management. The oldest/current primary admin is the permanent Super Admin/Owner.
ALTER TABLE public.admin_accounts ADD COLUMN IF NOT EXISTS full_name text;
ALTER TABLE public.admin_accounts ADD COLUMN IF NOT EXISTS role text NOT NULL DEFAULT 'admin' CHECK (role IN ('super_admin','admin'));
ALTER TABLE public.admin_accounts ADD COLUMN IF NOT EXISTS permissions jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE public.admin_accounts ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES public.admin_accounts(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_admin_accounts_active ON public.admin_accounts(active);
UPDATE public.admin_accounts SET role='super_admin' WHERE id = (SELECT id FROM public.admin_accounts ORDER BY created_at ASC LIMIT 1);
