# BES-AI V18 — Vercel Edition

BES (Best Education Service) website prepared for Vercel + Supabase + OpenAI.

### Includes
- BES public home page
- BES-AI real OpenAI backend through `/api/ai-tutor`
- Student activation using BES-provided Student ID + PIN
- Student login using Student ID + PIN
- Student profile, optional gallery photo and printable BES card
- Public verified-student reviews with private student identity
- Admin review moderation and student Ban/Unban/Delete controls
- Admin-managed announcement/ad carousel
- Supabase-backed student, review, ads and results data

### Vercel setup
See `VERCEL-DEPLOY.md`.

### Database setup
Run `supabase-migration.sql` in Supabase SQL Editor once.

### Environment variables
See `.env.example` and `VERCEL-DEPLOY.md`. Never expose the Supabase service-role key or OpenAI API key in browser code.

## Self-registration update
Run `supabase-self-registration.sql` once in Supabase. Students can then use **Create Account** with email, name, a 6–8 character alphanumeric PIN and a strong password. BES automatically issues a BES Student ID and signs the student in; the student then completes class, roll number, age, subjects and optional photo in the portal. Future logins use **BES ID + PIN**.

## Latest additions
- New Admission flow with automatic admission timestamp and unique BES Roll Number / Account ID.
- Student portal keeps Materials and Tests behind authentication.
- Admin-managed paid/free admission mode.
- Payment records with PayFast/Easypaisa provider options and bank transfer details.
- Admin permissions and audit-log tables.
- Public AI is separate from private student AI history; private AI history is session-scoped to the signed-in student.
