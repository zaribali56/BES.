-- BES production database schema for Neon Postgres
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id TEXT UNIQUE,
  full_name TEXT NOT NULL,
  class_level TEXT CHECK (class_level IS NULL OR class_level IN ('9th','10th','11th','12th')),
  roll_number TEXT,
  pin_hash TEXT NOT NULL,
  pin_salt TEXT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  banned BOOLEAN NOT NULL DEFAULT FALSE,
  email TEXT UNIQUE,
  password_hash TEXT,
  password_salt TEXT,
  age INTEGER,
  subjects TEXT,
  profile_photo TEXT,
  profile_completed BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (class_level, roll_number)
);

CREATE TABLE IF NOT EXISTS results (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  subject TEXT,
  marks NUMERIC,
  total_marks NUMERIC,
  percentage NUMERIC,
  grade TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_students_lookup ON students (class_level, roll_number);
CREATE INDEX IF NOT EXISTS idx_results_student ON results (student_id, created_at DESC);

-- For existing databases created before student self-registration
ALTER TABLE students ADD COLUMN IF NOT EXISTS student_id TEXT UNIQUE;
CREATE INDEX IF NOT EXISTS idx_students_student_id ON students (student_id);

-- Private BES-AI chat history: only the signed-in student can access their own messages.
CREATE TABLE IF NOT EXISTS ai_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('user','assistant')),
  content TEXT NOT NULL,
  mode TEXT NOT NULL DEFAULT 'normal',
  attachment_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_ai_messages_student_time ON ai_messages (student_id, created_at ASC);

CREATE TABLE IF NOT EXISTS reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  review_text TEXT NOT NULL CHECK (char_length(review_text) BETWEEN 5 AND 800),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT reviews_one_per_student UNIQUE (student_id)
);
CREATE INDEX IF NOT EXISTS idx_reviews_public ON reviews (active, created_at DESC);


ALTER TABLE students ADD COLUMN IF NOT EXISTS email TEXT UNIQUE;
ALTER TABLE students ADD COLUMN IF NOT EXISTS password_hash TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS password_salt TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS age INTEGER;
ALTER TABLE students ADD COLUMN IF NOT EXISTS subjects TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS profile_photo TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS profile_completed BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS ads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  body TEXT,
  image_url TEXT,
  background_color TEXT NOT NULL DEFAULT '#0b1824',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  interval_ms INTEGER NOT NULL DEFAULT 4500 CHECK (interval_ms BETWEEN 2000 AND 15000),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_ads_public ON ads(active, sort_order, created_at DESC);

-- BES student identity/profile fields
ALTER TABLE students ADD COLUMN IF NOT EXISTS father_name TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS date_of_birth DATE;
ALTER TABLE students ADD COLUMN IF NOT EXISTS field TEXT;
ALTER TABLE students ADD COLUMN IF NOT EXISTS admission_year INTEGER;
ALTER TABLE students ADD COLUMN IF NOT EXISTS phone TEXT;
CREATE INDEX IF NOT EXISTS idx_students_year_class_field ON students(admission_year,class_level,field);
