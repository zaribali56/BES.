// BES-AI V18 — Vercel Hobby-compatible API router
// All API handlers live outside /api so Vercel creates ONE Serverless Function.
const routes = {
  'admin-ads': require('../server/api/admin-ads'),
  'admin-change-password': require('../server/api/admin-change-password'),
  'admin-login': require('../server/api/admin-login'),
  'admin-logout': require('../server/api/admin-logout'),
  'admin-reviews': require('../server/api/admin-reviews'),
  'admin-stats': require('../server/api/admin-stats'),
  'admin-student': require('../server/api/admin-student'),
  'admin-students': require('../server/api/admin-students'),
  'ads': require('../server/api/ads'),
  'ai-chat': require('../server/api/ai-chat'),
  'ai-image': require('../server/api/ai-image'),
  'ai-tutor': require('../server/api/ai-tutor'),
  'health': require('../server/api/health'),
  'my-review': require('../server/api/my-review'),
  'reviews': require('../server/api/reviews'),
  'student-login': require('../server/api/student-login'),
  'student-logout': require('../server/api/student-logout'),
  'student-me': require('../server/api/student-me'),
  'student-profile': require('../server/api/student-profile'),
  'student-signup': require('../server/api/student-signup')
};

module.exports = async function(req, res) {
  const raw = req.query && req.query.route;
  const route = Array.isArray(raw) ? raw[0] : String(raw || '').replace(/^\/+|\/+$/g, '');
  const handler = routes[route];
  if (!handler) {
    res.status(404).json({ error: 'API route not found.' });
    return;
  }
  try {
    return await handler(req, res);
  } catch (e) {
    console.error('BES API router error', route, e);
    if (!res.headersSent) res.status(500).json({ error: 'Internal server error.' });
  }
};
