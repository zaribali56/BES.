// BES-AI V18 — Cloudflare Worker test runtime
// Keeps the existing BES pages/API handlers while adapting the Vercel-style API
// request/response contract to the Cloudflare Workers Fetch API.

import adminAds from './server/api/admin-ads.js';
import adminChangePassword from './server/api/admin-change-password.js';
import adminLogin from './server/api/admin-login.js';
import adminLogout from './server/api/admin-logout.js';
import adminReviews from './server/api/admin-reviews.js';
import adminStats from './server/api/admin-stats.js';
import adminStudent from './server/api/admin-student.js';
import adminStudents from './server/api/admin-students.js';
import ads from './server/api/ads.js';
import aiChat from './server/api/ai-chat.js';
import aiImage from './server/api/ai-image.js';
import aiTutor from './server/api/ai-tutor.js';
import health from './server/api/health.js';
import myReview from './server/api/my-review.js';
import reviews from './server/api/reviews.js';
import studentLogin from './server/api/student-login.js';
import studentLogout from './server/api/student-logout.js';
import studentMe from './server/api/student-me.js';
import studentProfile from './server/api/student-profile.js';
import studentSignup from './server/api/student-signup.js';
import adminPayments from './server/api/admin-payments.js';
import payments from './server/api/payments.js';
import adminAudit from './server/api/admin-audit.js';
import adminPermissions from './server/api/admin-permissions.js';
import adminManage from './server/api/admin-manage.js';
import studentComplaints from './server/api/student-complaints.js';
import adminComplaints from './server/api/admin-complaints.js';

const routes = {
  'admin-ads': adminAds,
  'admin-change-password': adminChangePassword,
  'admin-login': adminLogin,
  'admin-logout': adminLogout,
  'admin-reviews': adminReviews,
  'admin-stats': adminStats,
  'admin-student': adminStudent,
  'admin-students': adminStudents,
  'ads': ads,
  'ai-chat': aiChat,
  'ai-image': aiImage,
  'ai-tutor': aiTutor,
  'health': health,
  'my-review': myReview,
  'reviews': reviews,
  'student-login': studentLogin,
  'student-logout': studentLogout,
  'student-me': studentMe,
  'student-profile': studentProfile,
  'student-signup': studentSignup,
  'admin-payments': adminPayments,
  'payments': payments,
  'admin-audit': adminAudit,
  'admin-permissions': adminPermissions,
  'admin-manage': adminManage,
  'student-complaints': studentComplaints,
  'admin-complaints': adminComplaints
};

const pageRoutes = {
  '/': '/index.html',
  '/bes-ai': '/bes-ai.html',
  '/admin': '/admin.html',
  '/student-login': '/student-login.html',
  '/admission': '/admission.html',
  '/student': '/student.html',
  '/student-card': '/student-card.html',
  '/student-materials': '/student-materials.html',
  '/materials': '/materials.html',
  '/material-library': '/material-library.html',
  '/results': '/results.html'
};

function headersObject(headers) {
  const out = {};
  for (const [k, v] of headers.entries()) out[k.toLowerCase()] = v;
  return out;
}

function makeReq(request, url, body) {
  return {
    method: request.method,
    headers: headersObject(request.headers),
    body,
    query: Object.fromEntries(url.searchParams.entries()),
    on() {}
  };
}

function makeRes() {
  let statusCode = 200;
  const headers = new Headers();
  let body = null;
  return {
    status(code) { statusCode = code; return this; },
    setHeader(name, value) {
      // Node-style handlers use Set-Cookie for auth sessions.
      if (name.toLowerCase() === 'set-cookie') headers.append(name, value);
      else headers.set(name, String(value));
    },
    json(value) { body = value; return this; },
    get response() {
      if (body === null) body = {};
      return new Response(JSON.stringify(body), {
        status: statusCode,
        headers: headers
      });
    }
  };
}

async function handleApi(request, env, ctx) {
  const url = new URL(request.url);
  const route = url.pathname.replace(/^\/api\/?/, '').replace(/\/+$/, '');
  const modulePath = routes[route];
  if (!modulePath) return new Response(JSON.stringify({ error: 'API route not found.' }), { status: 404, headers: { 'content-type': 'application/json' } });

  globalThis.__BES_ENV = env;
  if (!globalThis.process) globalThis.process = { env }; else globalThis.process.env = env;
  const handler = modulePath;
  let body = undefined;
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    const text = await request.text();
    try { body = JSON.parse(text || '{}'); } catch { body = {}; }
  }
  const req = makeReq(request, url, body);
  const res = makeRes();
  try {
    await handler(req, res);
    return res.response;
  } catch (e) {
    console.error('BES Worker API error:', route, e);
    return new Response(JSON.stringify({ error: 'Internal server error.' }), { status: 500, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } });
  }
}

async function serveStatic(request, env) {
  const url = new URL(request.url);
  let path = pageRoutes[url.pathname] || url.pathname;
  if (!path.startsWith('/')) path = '/' + path;
  return env.ASSETS.fetch(new Request(new URL(path, url), request));
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/')) return handleApi(request, env, ctx);
    return serveStatic(request, env);
  }
};
