-- BES Reviews + moderation migration for Supabase
-- Run once in Supabase SQL Editor.

ALTER TABLE public.students ADD COLUMN IF NOT EXISTS banned boolean NOT NULL DEFAULT false;
CREATE INDEX IF NOT EXISTS idx_students_banned ON public.students(banned);

CREATE TABLE IF NOT EXISTS public.reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating BETWEEN 1 AND 5),
  review_text text NOT NULL CHECK (char_length(review_text) BETWEEN 5 AND 800),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT reviews_one_per_student UNIQUE (student_id)
);
CREATE INDEX IF NOT EXISTS idx_reviews_public ON public.reviews(active, created_at DESC);
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;


-- Student profile / account fields
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS email TEXT UNIQUE;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS password_hash TEXT;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS password_salt TEXT;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS age INTEGER;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS subjects TEXT;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS profile_photo TEXT;
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS profile_completed BOOLEAN NOT NULL DEFAULT FALSE;

-- Admin-managed public ad carousel
CREATE TABLE IF NOT EXISTS public.ads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  body text,
  image_url text,
  background_color text NOT NULL DEFAULT '#0b1824',
  active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  interval_ms integer NOT NULL DEFAULT 4500 CHECK (interval_ms BETWEEN 2000 AND 15000),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_ads_public ON public.ads(active, sort_order, created_at DESC);
ALTER TABLE public.ads ENABLE ROW LEVEL SECURITY;
