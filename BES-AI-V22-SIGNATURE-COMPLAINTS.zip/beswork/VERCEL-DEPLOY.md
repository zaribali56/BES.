# BES-AI V18 — Vercel deployment

This version is prepared for Vercel Serverless Functions + Supabase.

## 1. Import the project
Upload/import this folder/ZIP into Vercel as a new project. Framework preset can be **Other**. No build command is required.

## 2. Environment Variables
Add these in Vercel Project Settings → Environment Variables:

- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `SESSION_SECRET` — long random secret (at least 32 characters)
- `OPENAI_API_KEY`
- `OPENAI_MODEL` — optional, defaults to `gpt-4.1-mini`
- `OPENAI_IMAGE_MODEL` — optional, defaults to `gpt-image-1`
- `OPENAI_IMAGE_QUALITY` — optional, defaults to `medium`
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`

Use the same values for Production and Preview if both environments are needed.

## 3. Supabase
Run `supabase-migration.sql` once in Supabase SQL Editor. The Vercel API uses the Supabase service-role key only on the server, so do not expose it in browser code.

## 4. Routes
- `/` — BES home
- `/bes-ai` — BES-AI
- `/student-login` — student activation/login
- `/student` — student portal
- `/student-card` — printable BES student card
- `/admin` — administrator panel
- `/api/*` — Vercel serverless API routes

## 5. Student account flow
BES admin first creates a student record and provides the generated BES ID + PIN. The student activates that pre-created ID with email, name, strong password, and optional profile information/photo. Later login is BES ID + PIN.

## 6. Reviews
Only an authenticated, active, non-banned BES student can create/update one review. Public visitors see only the review text, rating and generic verified-student label. Admin sees the linked student's private account details and can hide/delete the review or ban/unban the student.

## 7. Ads
Admin can publish announcements from `/admin`. Active ads are returned by `/api/ads` and displayed in the public home carousel. If there are no active ads, the public ads section stays hidden.

## 8. Important
Do not paste secrets into HTML or JavaScript. After changing environment variables, redeploy the Vercel project.
