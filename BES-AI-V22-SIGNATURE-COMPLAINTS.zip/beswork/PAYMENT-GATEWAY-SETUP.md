# BES Payment Gateway Setup

## Current architecture
BES keeps admissions FREE by default. Admin can later switch the admission mode to PAID from the Admin Panel.

The project includes a payment abstraction and records transactions in the `payments` table. It supports:
- PayFast as the primary online-gateway provider option.
- Easypaisa as a provider option for future merchant onboarding.
- Bank transfer details (Bank Name, Account Title, IBAN, Account Number, Instructions).
- Payment statuses: pending, paid, failed, cancelled, refunded.

## Important for live payments
A real payment gateway cannot be made live from code alone. The merchant must first be approved by the gateway provider and receive merchant credentials. PayFast currently provides API/redirect integrations and supports bank-account, card, mobile-wallet and Raast payment methods; PayFast says live credentials are issued after merchant onboarding and sandbox testing.

Use Worker secrets for gateway credentials. Never put secret keys in public HTML or client-side JavaScript.

Recommended Worker secrets/configuration:
- PAYFAST_CHECKOUT_URL (approved hosted checkout URL, when supplied by PayFast)
- PAYFAST_MERCHANT_ID
- PAYFAST_SECURE_KEY
- EASYPAISA_MERCHANT_ID
- EASYPAISA_STORE_ID

Until the live provider credentials are configured, BES can record a pending payment and display configured bank-transfer instructions. This makes the feature testable without pretending a real payment was completed.
