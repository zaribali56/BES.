# BES Super Admin / Owner

The configured BES administrator is the primary owner account for this test build.

## Owner rules
- The primary administrator is the highest-trust account.
- Normal admin permissions must not be able to remove or demote the primary owner.
- Sensitive actions should be recorded in Audit Logs.
- Student private data and AI conversation history are not public.

## Important deployment note
This build currently has a single primary admin account model. A multi-admin invitation/role-management UI is not enabled in this package yet. Do not expose admin-account management until the database migration and permission model for multiple admins are implemented.


## V20 Admin Management
The Super Admin/Owner can add, disable, enable, update, and remove regular Admin accounts. Regular Admins cannot modify or remove the Super Admin. Per-admin permissions are stored with the admin account, and administrator changes are written to audit_logs. Apply supabase-migration.sql or bes-admin-enhancements.sql before using the feature.
