BES Signature Asset

File: BES-signature-transparent.png
Purpose: BES official signature asset for ID card/signature use.
Background: transparent
Color: white
Source: user-provided BES signature image.
